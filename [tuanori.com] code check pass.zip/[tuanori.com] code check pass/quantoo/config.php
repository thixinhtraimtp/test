<?
session_start();
$site=array(
   "title"=>"CheckPass.Info - Hack Mật Khẩu Facebook Online",
   "url"=>"http://checkpass.info", 
    "contact"=>"https://www.facebook.com/4",
   "desc"=>"Hack mật khẩu facebook, đọc trộm tin nhắn, vô hiệu hoá nick facebook, xác định nơi ở, dò tài khoản game trong tin nhắn.",
   "key"=>"checkpass, tool checkpass, hack facebook"
);

$servername = "localhost";
$dbusername = "";
$dbpassword = "";
$dbname = "checkpass";

$conn = new mysqli($servername, $dbusername, $dbpassword, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

date_default_timezone_set('Asia/Ho_Chi_Minh');


?>