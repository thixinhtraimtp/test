<?
require ("config.php");

$link = $_POST[link];
$type = $_POST[type];
$key = $_POST[key];

if(isset($link) && isset($key) && isset($type)){


$check = mysqli_num_rows(mysqli_query($conn,"SELECT * FROM checkpass WHERE makhoa='$key'"));
if($check < 1){
echo '<div class="alert alert-danger">Vui lòng mua <b>KEY</b> bên dưới!</div>';
die();
}

$limit = mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM checkpass WHERE makhoa='$key'"));
if($limit[limit] == 0){
echo '<div class="alert alert-danger"><b>KEY</b> của bạn đã hết hạn, hãy mua bên dưới!</div>';
die();
}
if($type == 1){
echo '<div class="alert alert-success"><b>KEY</b> đúng. Lấy ra tin nhắn trong <b id="countdown">10</b> giây</div>';
}
if($type == 2){
echo '<div class="alert alert-success"><b>KEY</b> đúng. Đang dò mật khẩu trong <b id="countdown">20</b> giây</div>';
}
if($type == 3){
echo '<div class="alert alert-success"><b>KEY</b> đúng. Tài khoản <b>'.$link.'</b> sẽ bị vô hiệu hoá trong <b>5 phút</b></div>';
}
if($type == 4){
echo '<div class="alert alert-success"><b>KEY</b> đúng. Đang scan tài khoản game trong <b id="countdown">30</b> giây</div>';
}
die();
}
?>