                                
</div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
<div id="footer-sec">
        &copy; 2020 Copyright by <a href="<? echo $site[contact] ?>" target="_blank">Mark Zuckerberg</a>.<br/>
All Rights Reserved
    </div>
    <!-- /. FOOTER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="<? echo $site[url] ?>/assets/js/jquery-1.10.2.js"></script>
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"> 
    </script> 
    <!-- BOOTSTRAP SCRIPTS -->
    <script src="<? echo $site[url] ?>/assets/js/bootstrap.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="<? echo $site[url] ?>/assets/js/jquery.metisMenu.js"></script>
     <!-- WIZARD SCRIPTS -->
    <script src="<? echo $site[url] ?>/assets/js/wizard/modernizr-2.6.2.min.js"></script>
    <script src="<? echo $site[url] ?>/assets/js/wizard/jquery.cookie-1.3.1.js"></script>
    <script src="<? echo $site[url] ?>/assets/js/wizard/jquery.steps.js"></script>
    <!-- CUSTOM SCRIPTS -->
    <script src="<? echo $site[url] ?>/assets/js/custom.js"></script>

<script>
if(window.location.protocol != 'https:') {
      location.href = location.href.replace("http://", "https://");
    }
</script>
</body>
</html>
