<?PHP
include('config.php');
function creatSign($partner_key, $params)
  {
        $data = array();
        $data['request_id'] = $params['request_id'];
        $data['code'] = $params['code'];
        $data['partner_id'] = $params['partner_id'];
        $data['serial'] = $params['serial'];
        $data['telco'] = $params['telco'];
        $data['command'] = $params['command'];
        ksort($data);
        $sign = $partner_key;
        foreach ($data as $item) {
            $sign .= $item;
        }
        return md5($sign);
  }

$partner_id = '7815820951'; //ID thesieure
$partner_key = '0f63aab84cb3e121233a55e51d55872f'; /// thesieure

if(isset($_POST['mathe']))
{
    
    if(empty($_POST[loaithe]))
    {
        $msg = 'Vui lòng chọn loại thẻ.';
        $c = false;
    }
    else
    if(empty($_POST[menhgia]))
    {
        $msg = 'Vui lòng chọn mệnh giá.';
        $c = false;
    }
    else
    if(empty($_POST[seri]))
    {
        $msg = 'Vui lòng nhập Serial.';
        $c = false;
    }
    else
    if(empty($_POST[mathe]))
    {
        $msg = 'Vui lòng nhập mã thẻ.';
        $c = false;
    }
    else
    {
            $dataPost = array();
			$dataPost['partner_id'] = $partner_id;
			$dataPost['request_id'] = rand(100000,999999);
			$dataPost['telco'] = $_POST[loaithe];
			$dataPost['amount'] = $_POST[menhgia];
			$dataPost['serial'] = $_POST[seri];
			$dataPost['code'] = $_POST[mathe];
			$dataPost['command'] = 'charging';
			$sign = creatSign($partner_key, $dataPost);
			$dataPost['sign'] = $sign;
			$data = http_build_query($datapost);
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, "https://thesieure.com/chargingws/v2");
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $dataPost);
            $actual_link = (isset($_SERVER['HTTPS']) ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
            curl_setopt($ch, CURLOPT_REFERER, $actual_link);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            $result2 = curl_exec($ch);
            $result = json_decode($result2);
            curl_close($ch);
			if($result->status == 99)
			{
			  $key = 'checkpass'.rand(2003,2020);
			    $msg = 'Vui lòng đợi xử lí trong <b id="countdown">30</b> giây</div>';

$conn->query("INSERT INTO `checkpass` SET  `makhoa` = '$key'");
			  $code = 99;
			  $c = false;
			}
			else
			if($result->status ==1)
			{
$key = 'checkpass'.rand(2003,2020);
			    $msg = "Thành công<b> KEY </b>của bạn là: ".$key;
$conn->query("INSERT INTO `checkpass` SET  `makhoa` = '$key'");
			    $code =1;
			    $c = false;
			}
			else
			if($result->status ==2)
			{
			    $msg = "Nạp sai mệnh giá. ";
			    $code =1;
			}
			else
			if($result->status ==3)
			{
			    $msg = "Vui lòng kiểm tra lại serial, mã thẻ.";
			    $code =3;
			    $c = false;
			}
			else
			if($result->status ==4)
			{
			    $msg = "Hệ thống đang bảo trì.";
			    $code =4;
			    $c = false;
			}
			else
			{
			    $msg = $result->message;
			    $c=false;
			    $code =5;
			}
	


        
    }
    
   
$n[mess] = $msg;
$n[status] = $c;
$n[code] = $code;
$n[khac] = $a;
echo json_encode($n);
}
?>