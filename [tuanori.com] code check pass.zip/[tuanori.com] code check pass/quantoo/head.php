﻿<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title><? echo $site[title] ?></title>
    <meta name="search engines" content="Aeiwi, Alexa, AllTheWeb, AltaVista, AOL Netfind, Anzwers, Canada, DirectHit, EuroSeek, Excite, Overture, Go, Google, HotBot. InfoMak, Kanoodle, Lycos, MasterSite, National Directory, Northern Light, SearchIt, SimpleSearch, WebsMostLinked, WebTop, What-U-Seek, AOL, Yahoo, WebCrawler, Infoseek, Excite, Magellan, LookSmart, bing, CNET, Googlebot" />
<meta property="og:type" content="website" />
<meta name="description" content="Share Key Check Pass Facebook, <? echo $site[desc] ?>"/>
<meta name="keywords" content="sieuhack, check pass online, key check pass, check pass fb, hack mật khẩu fb,<? echo $site[key] ?>" />
<meta name="robots" content="index, follow" /> 
<meta name="robot" content="index, follow"/>
<meta name="googlebot" content="index, follow" /> 
<meta name="YandexBot" content="index, follow" /> 
<link rel="shortcut icon" href="https://static.xx.fbcdn.net/rsrc.php/v3/ya/r/O2aKM2iSbOw.png">
    <!-- BOOTSTRAP STYLES-->
    <link href="<? echo $site[url] ?>/assets/css/bootstrap.css" rel="stylesheet" />
    <!--WIZARD STYLES-->
    <link href="<? echo $site[url] ?>/assets/css/wizard/normalize.css" rel="stylesheet" />
    <link href="<? echo $site[url] ?>/assets/css/wizard/wizardMain.css" rel="stylesheet" />
    <link href="<? echo $site[url] ?>/assets/css/wizard/jquery.steps.css" rel="stylesheet" />
    <!-- FONTAWESOME STYLES-->
    <link href="<? echo $site[url] ?>/assets/css/font-awesome.css" rel="stylesheet" />
    <!--CUSTOM BASIC STYLES-->
    <link href="<? echo $site[url] ?>/assets/css/basic.css" rel="stylesheet" />
    <!--CUSTOM MAIN STYLES-->
    <link href="<? echo $site[url] ?>/assets/css/custom.css" rel="stylesheet" />
    <!-- GOOGLE FONTS-->
    <link href='http://fonts.googleapis.com/css?family=Poppins' rel='stylesheet' type='text/css' />
<style>
* {
  font-family: 'Poppins', sans-serif;
   word-wrap: break-word;
}
button {
  font-family: 'Poppins', sans-serif;
} 
select {
  font-family: 'Poppins', sans-serif;
} 
input {
  font-family: 'Poppins', sans-serif;
}
</style>

</head>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="/">CHECKPASS.INFO</a>
            </div>

            
        </nav>
        <!-- /. NAV TOP  -->
        <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
                    


                    <li>
                        <a href="/"><i class="fa fa-home "></i>Trang Chủ</a>
                    </li>                                                            
                    <li>
                        <a href="/zalo.php"><i class="fa fa-share-square"></i>Hack Zalo</a>
                    </li>                                                            
                    <li>
                        <a href="/nhan-key-free.php"><i class="fa fa-key"></i>Nhận Key Miễn Phí</a>
                    </li>
                </ul>

            </div>

        </nav>
        <!-- /. NAV SIDE  -->

<div id="page-wrapper">
            <div id="page-inner">
                