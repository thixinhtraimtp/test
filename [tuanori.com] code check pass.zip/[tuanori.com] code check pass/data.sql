-- Adminer 4.7.6 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP TABLE IF EXISTS `checkpass`;
CREATE TABLE `checkpass` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `makhoa` text COLLATE utf8_unicode_ci NOT NULL,
  `limit` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `checkpass` (`id`, `makhoa`, `limit`) VALUES
(1,	'ok',	'5'),
(2,	'checkpass2006',	''),
(3,	'checkpass2004',	''),
(4,	'checkpass2018',	''),
(5,	'checkpass2012',	'');

-- 2020-08-10 09:08:21