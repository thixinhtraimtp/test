<?
require ("quantoo/config.php");
require ("quantoo/head.php");
?>
<div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line text-center"> NHẬN KEY MIỄN PHÍ </h1>
                        <h1 class="page-subhead-line"><? echo $site[desc] ?></h1>

                    </div>
                </div>
                <!-- /. ROW  -->
             
            <div class="row">
                <div class="col-md-6">
                   
 <div class="panel panel-primary">
                        <div class="panel-heading">
                            Bạn Hãy Làm Theo Các Bước Sau
                        </div>
                        <div class="panel-body">
<!-- Form -->              
<p><b>Bước 1:</b> Các bạn hãy dùng phần mềm quay màn hình như <span class="badge badge-success">Az Screen Recorder, Mobizen,...</span> quay màn hình lại <span class="badge badge-primary"><? echo $site[url] ?></span>. (Tối thiếu video dài trên <b>3p</b> nhé)<br>
            <b>Bước 2:</b> Vào ứng dụng <b>Youtube</b> sau đó nhấn vào icon tải lên để upload video, tải tệp video vừa download lên, phần mô tả, tiêu đề và thẻ thì bạn làm như ví dụ bên dưới.</p>
            <div class="form-group">
                <label>Tiêu đề video (có thể chỉnh sửa)</label>
                <input class="form-control" type="text" placeholder="Tiêu đề video..." value="Phần mềm checkpass facebook online mới nhất 2020 - hack mật khẩu facebook - Checkpass.info">
            </div>
           <div class="form-group">
    <label for="exampleFormControlTextarea1">Mô tả video (vui lòng copy hết và không chỉnh sửa gì)</label>
    <textarea class="form-control" id="exampleFormControlTextarea1" rows="3">#hackfb #checkpassonline #checkonline
- Link check : https://checkpass.info/
- Facebook hỗ trợ : https://www.facebook.com/CheckPass.Info
- Key miễn phí : comment địa chỉ email hoặc liên hệ facebook trên để nhận key miễn phí, đăng ký kênh và bật chuông nữa nhé!
- Keywords : check pass online, check pass online v5, hack mật khẩu fb, hack fb online, check pass facebook online, Checkpass.info , hack mật khẩu zalo, hack mật khẩu zalo online, check pass zalo, vô hiệu hoá nick zalo, vô hiệu hoá nick facebook</textarea>
  </div>
  <div class="form-group">
                <label>Thẻ của video (có thể chỉnh sửa)</label>
                <input class="form-control" type="text" placeholder="Thẻ..." value="check pass online, check pass online v5, hack mật khẩu fb, hack fb online, check pass facebook online, checkpass-info, checkpass.info">
            </div>
              <p><b>Bước cuối:</b> Sao chép liên kết của video sau đó gửi cho admin để xem xét (nhớ gửi yêu cầu kết bạn trước!): <a href="https://www.facebook.com/CheckPass.Info">https://www.facebook.com/CheckPass.Info</a></p>


<!--/Form-->
                        </div>
                    </div>
<div class="panel panel-primary">
                        <div class="panel-heading">
                            Phần Thưởng Các Bạn Là Gì ?
                        </div>
                        <div class="panel-body">
<!-- Form -->              
<li>Chúng tôi sẽ tặng thẻ cào từ <b>100.000</b> tới <b>1.000.000</b> cho các video quảng cáo đạt số lượng tương tác tương đối cao (trên 1K lượt xem).</li>
  <li>Những người tham gia quảng cáo sẽ nhận ngay <b>1 KEY CHECK PASS VĨNH VIỄN</b>.</li>
  <li>Những clip đạt trên <b>10.000</b> lượt xem sẽ có ưu đãi tặng thêm : <b>1 CHIẾC ĐIỆN THOẠI OPPO RENO 3 PRO</b>.</li>
  <li>Những clip thu hút nhiều doanh thu về cho website sẽ được ưu đãi 1 coupon giảm 99% khi mua hàng tại các shop online như: <b>Lazada</b>,<b>Shopee</b>,<b>Thegioididong</b>,...</li>
  <li>Những bạn đóng góp nhiều lượt thu hút nhất cho website sẽ được tham gia tuyển làm MOD, Supporter của website lương lên đến <b>8 triệu</b> 1 tháng và có cơ hội nhận được vị trí kiểm duyệt thẻ (lương <b>15 triệu</b> 1 tháng).</li>
  
<!--/Form-->
                        </div>
                    </div>
</div>
<?
require ("quantoo/foot.php");
?>