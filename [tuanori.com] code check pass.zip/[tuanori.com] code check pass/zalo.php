<?
require ("quantoo/config.php");
require ("quantoo/head.php");

require ("pages/zalo.php");

require ("quantoo/foot.php");

?>