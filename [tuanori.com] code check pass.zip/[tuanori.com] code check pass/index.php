<?
require ("quantoo/config.php");
require ("quantoo/head.php");

require ("pages/trangchu.php");

require ("quantoo/foot.php");

?>